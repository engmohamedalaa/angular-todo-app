export interface Task {
  id?: number; // ? refers to that it's optional
  text: string;
  day: string;
  reminder: boolean;
}
